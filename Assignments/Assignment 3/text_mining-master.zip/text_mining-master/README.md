# Text Mining and Analysis

This is the base repo for the text mining and analysis assignment. 
